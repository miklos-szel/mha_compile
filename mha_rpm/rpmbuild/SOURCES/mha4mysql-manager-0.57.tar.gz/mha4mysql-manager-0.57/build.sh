rm Makefile
dpkg-buildpackage -us -uc
